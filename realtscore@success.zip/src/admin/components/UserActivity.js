export default function UserActivity() {
  return <div>User Activity logs go here</div>;
}
