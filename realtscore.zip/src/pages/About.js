import React, { useState } from "react";
import Input from "../components/Input/Input";

function App() {
  const [num, setNum] = useState("");
  const [alpha, setAlpha] = useState("");
  const [alnum, setAlnum] = useState("");

  return (
    <div style={{ padding: "20px" }}>
      <h2>Custom Inputs</h2>

      <label>Numeric Only</label>
      <Input 
        placeholder="Enter numbers only" 
        value={num} 
        onChange={setNum} 
        mode="numeric" 
      />

      <label>Alphabets Only</label>
      <Input 
        placeholder="Enter alphabets only" 
        value={alpha} 
        onChange={setAlpha} 
        mode="alpha" 
      />

      <label>Alphanumeric Only</label>
      <Input 
        placeholder="Enter letters & numbers" 
        value={alnum} 
        onChange={setAlnum} 
        mode="alphanumeric" 
      />
    </div>
  );
}

export default App;
