export default function Explore() {
  return <h1>Explore Page</h1>;
}
