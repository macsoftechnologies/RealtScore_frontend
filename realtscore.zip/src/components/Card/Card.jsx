import React from 'react';
import styles from './Card.module.css';

export default function Card({ title, location, score, badges, children, footer }) {
  return (
    <div className={styles.card}>
      <div className={styles.header}>{title}</div>
      <p className={styles.location}>Location: {location}</p>
      <p className={styles.score}>Score: {score}</p>
      <div className={styles.badges}>
        {badges.map((badge, index) => (
          <span key={index} className={styles.badge + ' ' + styles[badge.type]}>
            {badge.label}
          </span>
        ))}
      </div>
      <div className={styles.actions}>{children}</div>
      {footer && <div className={styles.footer}>{footer}</div>}
    </div>
  );
}
