import React, { useState } from "react";
import Button from "../../components/Button/Button";
import Modal from "../../components/Modal/Modal";
import Input from "../../components/Input/Input";
import "./ManageProperties.css";
import Modalstyle from "../../components/Modal/Modal.module.css"; 

export default function ManageProperties() {
  // Initial properties (keep same for pagination demo)
  const [properties, setProperties] = useState([
    { id: 101, location: "Vizag Beach Road", latitude: 17.6868, longitude: 83.2185, score: 88, status: "Approved" },
    { id: 102, location: "Hyderabad Hitech City", latitude: 17.4483, longitude: 78.3915, score: 92, status: "Pending" },
    { id: 103, location: "Bangalore MG Road", latitude: 12.9716, longitude: 77.5946, score: 79, status: "Rejected" },
    { id: 104, location: "Chennai Marina Beach", latitude: 13.0827, longitude: 80.2707, score: 85, status: "Approved" },
    { id: 105, location: "Kolkata Park Street", latitude: 22.5726, longitude: 88.3639, score: 90, status: "Pending" },
    { id: 106, location: "Delhi Connaught Place", latitude: 28.6315, longitude: 77.2167, score: 87, status: "Approved" },
  ]);

  const pageSize = 3;
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = Math.ceil(properties.length / pageSize);
  const currentProperties = properties.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Modal & Form States
  const [modalOpen, setModalOpen] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [form, setForm] = useState({
    id: "",
    location: "",
    latitude: "",
    longitude: "",
    score: "",
    status: ""
  });
  const [errors, setErrors] = useState({});

  const openAddModal = () => {
    setEditIndex(null);
    setForm({ id: "", location: "", latitude: "", longitude: "", score: "", status: "" });
    setErrors({});
    setModalOpen(true);
  };

  const openEditModal = (globalIndex) => {
    const p = properties[globalIndex];
    setEditIndex(globalIndex);
    setForm({
      id: p.id,
      location: p.location,
      latitude: p.latitude,
      longitude: p.longitude,
      score: p.score,
      status: p.status
    });
    setErrors({});
    setModalOpen(true);
  };

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const validate = () => {
    const e = {};
    if (!form.id) e.id = "Required";
    if (!form.location) e.location = "Required";
    if (form.latitude === "" || isNaN(form.latitude) || form.latitude < -90 || form.latitude > 90)
      e.latitude = "Lat -90 to 90";
    if (form.longitude === "" || isNaN(form.longitude) || form.longitude < -180 || form.longitude > 180)
      e.longitude = "Lng -180 to 180";
    if (form.score === "" || isNaN(form.score) || form.score < 0 || form.score > 100)
      e.score = "0–100";
    if (!form.status) e.status = "Required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const saveProperty = () => {
    if (!validate()) return;

    const newProperty = {
      id: Number(form.id),
      location: form.location,
      latitude: Number(form.latitude),
      longitude: Number(form.longitude),
      score: Number(form.score),
      status: form.status
    };

    setProperties((prev) => {
      if (editIndex !== null) {
        const copy = [...prev];
        copy[editIndex] = newProperty;
        return copy;
      } else {
        return [...prev, newProperty];
      }
    });

    setModalOpen(false);
  };

  return (
    <div className="container-fulid my-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2 className="mp-title">Property List</h2>
        <Button variant="serchbtn" size="lg" onClick={openAddModal}>
          Add New Property
        </Button>
      </div>

      <div className="table-responsive">
        <table className="table table-borderless align-middle">
          <thead className="mp-table-head">
            <tr>
              <th>Property ID</th>
              <th>Location</th>
              <th>Latitude</th>
              <th>Longitude</th>
              <th>Score</th>
              <th>Status</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentProperties.map((prop) => {
              const globalIndex = properties.findIndex(p => p.id === prop.id);
              return (
                <tr key={prop.id}>
                  <td>#{prop.id}</td>
                  <td>{prop.location}</td>
                  <td>{prop.latitude}</td>
                  <td>{prop.longitude}</td>
                  <td>{prop.score}</td>
                  <td>{prop.status}</td>
                  <td className="text-right">
                    <Button
                      className="btn-add"
                      variant="serchbtn"
                      size="sm"
                      onClick={() => openEditModal(globalIndex)}
                    >
                      Edit
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-3">
          <Button
            variant="serchbtn"
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            className="pagination-btn"
            disabled={currentPage === 1}
          >
            &#8592; Prev
          </Button>

          {Array.from({ length: totalPages }, (_, i) => (
            <Button
              key={i + 1}
              onClick={() => setCurrentPage(i + 1)}
              className={`pagination-btn ${currentPage === i + 1 ? "active" : ""}`}
            >
              {i + 1}
            </Button>
          ))}

          <Button
            variant="serchbtn"
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            className="pagination-btn"
            disabled={currentPage === totalPages}
          >
            Next &#8594;
          </Button>
        </div>
      )}

      {/* Add / Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        className={`${Modalstyle.xlarge} ${Modalstyle.noScroll} my-custom-shadow`}
        title={editIndex !== null ? "Edit Property" : "Add New Property"}
      >
        <div className="modal-form">
          <div className="form-row">
            <Input
              placeholder="Property ID"
              value={form.id}
              onChange={(v) => handleChange("id", v)}
              mode="numeric"
              error={errors.id}
            />
            <Input
              placeholder="Location"
              value={form.location}
              onChange={(v) => handleChange("location", v)}
              error={errors.location}
            />
          </div>

          <div className="form-row">
            <Input
              placeholder="Latitude (-90 to 90)"
              value={form.latitude}
              onChange={(v) => handleChange("latitude", v)}
              error={errors.latitude}
            />
            <Input
              placeholder="Longitude (-180 to 180)"
              value={form.longitude}
              onChange={(v) => handleChange("longitude", v)}
              error={errors.longitude}
            />
          </div>

          <div className="form-row">
            <Input
              placeholder="Score (0–100)"
              value={form.score}
              onChange={(v) => handleChange("score", v)}
              mode="numeric"
              error={errors.score}
            />
            <Input
              placeholder="Status (Approved / Pending / Rejected)"
              value={form.status}
              onChange={(v) => handleChange("status", v)}
              error={errors.status}
            />
          </div>

          <Button
            variant="serchbtn"
            size="lg"
            onClick={saveProperty}
            className="mt-3 w-100"
          >
            {editIndex !== null ? "Update Property" : "Add Property"}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
