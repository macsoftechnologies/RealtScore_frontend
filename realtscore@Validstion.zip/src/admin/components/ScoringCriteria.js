export default function ScoringCriteria() {
  return <div>Scoring Criteria content goes here</div>;
}
